"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mod = void 0;
const BaseClasses_1 = require("C:/snapshot/project/obj/models/enums/BaseClasses");
const jsonc_1 = require("C:/snapshot/project/node_modules/jsonc");
const path_1 = __importDefault(require("path"));
class maskfix {
    async postDBLoad(container) {
        // get database from server
        const databaseServer = container.resolve("DatabaseServer");
        const tables = databaseServer.getTables();
        const itemDB = tables.templates.items;
        const itemHelper = container.resolve("ItemHelper");
        const fs = container.resolve("FileSystem");
        const configPath = path_1.default.resolve(__dirname, "../config.jsonc");
        const configFileContent = await fs.read(configPath);
        const configString = configFileContent.toString();
        const config = jsonc_1.jsonc.parse(configString);
        for (let item in itemDB) {
            if (itemDB[item]._type !== "Node") {
                const itemId = itemDB[item]._id;
                if (itemHelper.isOfBaseclass(itemId, BaseClasses_1.BaseClasses.FACECOVER)) {
                }
                itemDB[item]._props.BlocksHeadwear = config.FaceCover.removeBlocksHeadwear ? false : itemDB[item]._props.BlocksHeadwear;
                itemDB[item]._props.BlocksEarpiece = config.FaceCover.removeBlocksEarpiece ? false : itemDB[item]._props.BlocksEarpiece;
                itemDB[item]._props.BlocksFaceCover = config.FaceCover.removeBlocksFaceCover ? false : itemDB[item]._props.BlocksFaceCover;
                itemDB[item]._props.BlocksEyewear = config.FaceCover.removeBlocksEyewear ? false : itemDB[item]._props.BlocksEyewear;
                itemDB[item]._props.ConflictingItems = config.FaceCover.clearConflictingItems ? [] : itemDB[item]._props.ConflictingItems;
            }
        }
        tables.templates.items["55d7217a4bdc2d86028b456d"]._props.Slots[13]._props.filters[0].Filter.push("5a341c4686f77469e155819e");
    }
}
exports.mod = new maskfix();
//# sourceMappingURL=mod.js.map