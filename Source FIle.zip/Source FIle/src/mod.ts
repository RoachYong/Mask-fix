import { DependencyContainer } from "tsyringe";
import { ItemTpl } from "@spt/models/enums/ItemTpl";
import { IPostDBLoadMod } from "@spt/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { IDatabaseTables } from "@spt/models/spt/server/IDatabaseTables";
import { ItemHelper } from "@spt/helpers/ItemHelper";
import { BaseClasses } from "@spt/models/enums/BaseClasses";

class Mod implements IPostDBLoadMod
{
    public postDBLoad(container: DependencyContainer): void
    {
        // get database from server
        const databaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        const tables: IDatabaseTables = databaseServer.getTables();

        const maskList: string[] = [
            "657089638db3adca1009f4ca", // CQCM
            "6570aead4d84f81fd002a033", // Death Shadow
            "59e7715586f7742ee5789605", // respirator
            "5c1a1e3f2e221602b66cc4c2", // fake beard
            "5c1a1e3f2e221602b66cc4c2", // Glorious
            "62a09dd4621468534a797ac7", // Baddies red beard
            "5b432b6c5acfc4001a599bf0", // Deadly skull mask
            "60363c0c92ec1c31037959f5", // GP-7 gas mask 
            "5bd071d786f7747e707b93a3", // Jason mask
            "5e54f79686f7744022011103", // Pestily plague mask
            "5b432b2f5acfc4771e1c6622", // Shattered lightweight Mask
            "60a7ad2a2198820d95707a2e", // Tagilla Ubey
            "60a7ad3a0c5cb24b0134664a", // Tagilla Gorilla 
            "5b4326435acfc433000ed01d", // Neoprene Mask
            "5e71f6be86f77429f2683c44"  // Twitch Rivals 2020 mask

        ]

        maskList.forEach(mask => {
        
        tables.templates.items["55d7217a4bdc2d86028b456d"]._props.Slots[13]._props.filters[0].Filter.push(`${mask}`);
        })
    }
}

export const mod = new Mod();
