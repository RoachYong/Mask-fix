makes most but not all masks equippable into the eyewear slot

put in user/mods

	
the masks included are as followed
   
- Glorious E lightweight armored mask
- Baddies red beard
- Death Shadow Lightweight armored mask
- Fake White Beard
- CQCM armaored ballistic mask (Black)
- Deadly Skull mask 
- GP-7 gas mask
- Jason mask
- Pestily plague mask
- Shattered lightweight armored mask
- respirator
- Tagillas weldiunng mask "Gorilla"
- Tagillas welding mask "UBEY"
- Neoprene mask
- Twitch Rivals 2020 mask