export interface IWearClothingRequestData {
    Action: "CustomizationWear";
    suites: string[];
}
