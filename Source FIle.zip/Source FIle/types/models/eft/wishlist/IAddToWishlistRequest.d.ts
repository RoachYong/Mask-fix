export interface IAddToWishlistRequest {
    Action: string;
    items: Record<string, number>;
}
