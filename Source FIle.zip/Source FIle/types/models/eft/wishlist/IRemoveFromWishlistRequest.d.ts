export interface IRemoveFromWishlistRequest {
    Action: string;
    items: string[];
}
