export interface IChangeWishlistItemCategoryRequest {
    Action: string;
    item: string;
    category: number;
}
