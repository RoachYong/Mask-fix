export interface IMessageContentRagfair {
    offerId: string;
    count: number;
    handbookId: string;
}
