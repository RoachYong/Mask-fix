export interface IGetOtherProfileRequest {
    accountId: string;
}
