export interface IProfileChangeVoiceRequestData {
    voice: string;
}
