export interface IGetProfileSettingsRequest {
    /** Chosen value for profile.Info.SelectedMemberCategory */
    memberCategory: number;
    squadInviteRestriction: boolean;
}
