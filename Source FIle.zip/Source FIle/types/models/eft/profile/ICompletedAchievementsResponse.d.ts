export interface ICompletedAchievementsResponse {
    elements: Record<string, number>;
}
