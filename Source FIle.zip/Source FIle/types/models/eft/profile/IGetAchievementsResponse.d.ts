import { IAchievement } from "@spt/models/eft/common/tables/IAchievement";
export interface IGetAchievementsResponse {
    elements: IAchievement[];
}
