export interface IGetRaidTimeResponse {
    NewSurviveTimeSeconds?: number;
    OriginalSurvivalTimeSeconds: number;
}
