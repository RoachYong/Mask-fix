export interface IServerDetails {
    ip: string;
    port: number;
}
