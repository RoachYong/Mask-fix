export interface IGameStartResponse {
    utc_time: number;
}
