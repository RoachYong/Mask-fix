export interface IGameLogoutResponseData {
    status: string;
}
