import { IPrestige } from "@spt/models/eft/common/tables/IPrestige";
export interface IGetPrestigeResponse {
    elements: IPrestige;
}
