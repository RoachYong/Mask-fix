export interface IObtainPrestigeRequest {
    id: string;
    location: ILocation;
}
export interface ILocation {
    x: number;
    y: number;
    r: string;
}
