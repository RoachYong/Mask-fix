export interface IMatchGroupInviteSendRequest {
    to: string;
    inLobby: boolean;
}
