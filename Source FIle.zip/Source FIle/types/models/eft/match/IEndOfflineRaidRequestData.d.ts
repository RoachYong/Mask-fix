export interface IEndOfflineRaidRequestData {
    crc: number;
    exitStatus: string;
    exitName: string;
    raidSeconds: number;
}
