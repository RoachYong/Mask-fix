export interface IMatchGroupTransferRequest {
    aidToChange: string;
}
