export interface IProfileStatusRequest {
    groupId: number;
}
