export interface IStorePlayerOfferTaxAmountRequestData {
    id: string;
    tpl: string;
    count: number;
    fee: number;
}
