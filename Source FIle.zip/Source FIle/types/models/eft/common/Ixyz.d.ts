export interface Ixyz {
    x: number;
    y: number;
    z: number;
}
export interface Ixy {
    x: number;
    y: number;
}
