export interface IUIDRequestData {
    uid: string;
}
