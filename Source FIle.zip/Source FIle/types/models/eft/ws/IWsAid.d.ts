import { IWsNotificationEvent } from "@spt/models/eft/ws/IWsNotificationEvent";
export interface IWsAid extends IWsNotificationEvent {
    aid: number;
}
