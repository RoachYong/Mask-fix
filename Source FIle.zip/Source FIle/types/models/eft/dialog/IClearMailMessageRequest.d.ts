export interface IClearMailMessageRequest {
    dialogId: string;
}
