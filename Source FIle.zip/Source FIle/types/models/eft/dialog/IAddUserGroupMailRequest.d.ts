export interface IAddUserGroupMailRequest {
    dialogId: string;
    uid: string;
}
