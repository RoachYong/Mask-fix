export interface IChangeGroupMailOwnerRequest {
    dialogId: string;
    uid: string;
}
