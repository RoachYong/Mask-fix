export interface ICompleteQuestRequestData {
    Action: string;
    /** Quest Id */
    qid: string;
    removeExcessItems: boolean;
}
