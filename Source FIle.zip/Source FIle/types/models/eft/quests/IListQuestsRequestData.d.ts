export interface IListQuestsRequestData {
    completed: boolean;
}
