import { ILoginRequestData } from "@spt/models/eft/launcher/ILoginRequestData";
export type IRemoveProfileData = ILoginRequestData;
