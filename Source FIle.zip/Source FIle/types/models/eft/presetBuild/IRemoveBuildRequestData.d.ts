export interface IRemoveBuildRequestData {
    id: string;
}
