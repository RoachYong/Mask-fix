export interface IHideoutDeleteProductionRequestData {
    Action: "HideoutDeleteProductionCommand";
    recipeId: string;
    timestamp: number;
}
