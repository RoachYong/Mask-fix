export interface IHideoutCustomizationSetMannequinPoseRequest {
    Action: "HideoutCustomizationSetMannequinPose";
    poses: Record<string, string>;
    timestamp: number;
}
