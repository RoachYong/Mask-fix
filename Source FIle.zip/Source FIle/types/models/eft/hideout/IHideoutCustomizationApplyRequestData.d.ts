export interface IHideoutCustomizationApplyRequestData {
    Action: "HideoutCustomizationApply";
    /** Id of the newly picked item to apply to hideout */
    offerId: string;
    timestamp: number;
}
