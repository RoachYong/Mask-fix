export interface IHideoutCancelProductionRequestData {
    Action: "HideoutCancelProductionCommand";
    recipeId: string;
    timestamp: number;
}
