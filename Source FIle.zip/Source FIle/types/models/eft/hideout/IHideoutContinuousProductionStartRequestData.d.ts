export interface IHideoutContinuousProductionStartRequestData {
    Action: "HideoutContinuousProductionStart";
    recipeId: string;
    timestamp: number;
}
