export interface IGetAirdropLootRequest {
    containerId: string;
}
