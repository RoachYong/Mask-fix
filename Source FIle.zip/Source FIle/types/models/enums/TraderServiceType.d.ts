export declare enum TraderServiceType {
    EXUSEC_LOYALTY = "ExUsecLoyalty",
    ZRYACHIY_AID = "ZryachiyAid",
    CULTISTS_AID = "CultistsAid",
    BTR_ITEMS_DELIVERY = "BtrItemsDelivery",
    PLAYER_TAXI = "PlayerTaxi",
    BTR_BOT_COVER = "BtrBotCover",
    TRANSIT_ITEMS_DELIVERY = "TransitItemsDelivery"
}
