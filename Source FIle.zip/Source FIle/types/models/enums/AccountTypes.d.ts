export declare enum AccountTypes {
    SPT_DEVELOPER = "spt developer"
}
