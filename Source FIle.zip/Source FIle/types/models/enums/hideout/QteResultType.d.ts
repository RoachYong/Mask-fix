export declare enum QteResultType {
    NONE = "None",
    EXIT = "Exit"
}
