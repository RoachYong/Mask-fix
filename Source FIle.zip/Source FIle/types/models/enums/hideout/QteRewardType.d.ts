export declare enum QteRewardType {
    SKILL = "Skill",
    HEALTH_EFFECT = "HealthEffect",
    MUSCLE_PAIN = "MusclePain",
    GYM_ARM_TRAUMA = "GymArmTrauma"
}
