export declare enum ExitStatus {
    SURVIVED = "Survived",
    KILLED = "Killed",
    LEFT = "Left",
    RUNNER = "Runner",
    MISSINGINACTION = "MissingInAction",
    TRANSIT = "Transit"
}
