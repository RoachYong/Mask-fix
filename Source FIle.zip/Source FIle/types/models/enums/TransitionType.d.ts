export declare enum TransitionType {
    None = 0,
    Common = 1,
    Event = 2
}
