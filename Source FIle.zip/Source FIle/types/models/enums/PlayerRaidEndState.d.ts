export declare enum PlayerRaidEndState {
    SURVIVED = "survived",
    LEFT = "left",
    RUNNER = "runner",
    MISSING_IN_ACTION = "missinginaction",
    KILLED = "killed"
}
