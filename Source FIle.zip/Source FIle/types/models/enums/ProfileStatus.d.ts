export declare enum ProfileStatus {
    FREE = "Free",
    MATCH_WAIT = "MatchWait",
    BUSY = "Busy",
    LEAVING = "Leaving",
    TRANSFER = "Transfer"
}
