export declare enum EntryType {
    LOCAL = "LOCAL",
    DEBUG = "DEBUG",
    RELEASE = "RELEASE",
    BLEEDING_EDGE = "BLEEDING_EDGE",
    BLEEDING_EDGE_MODS = "BLEEDING_EDGE_MODS"
}
