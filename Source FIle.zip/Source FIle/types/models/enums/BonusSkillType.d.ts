export declare enum BonusSkillType {
    PHYSICAL = "Physical",
    COMBAT = "Combat",
    SPECIAL = "Special",
    PRACTICAL = "Practical",
    MENTAL = "Mental"
}
