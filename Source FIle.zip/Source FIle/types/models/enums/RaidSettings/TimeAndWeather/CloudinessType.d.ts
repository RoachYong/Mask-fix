export declare enum CloudinessType {
    CLEAR = "Clear",
    PARTLY_CLOUDY = "PartlyCloudy",
    CLOUDY = "Cloudy",
    CLOUDY_WITH_GAPS = "CloudyWithGaps",
    HEAVY_CLOUD_COVER = "HeavyCloudCover",
    THUNDER_CLOUD = "Thundercloud"
}
