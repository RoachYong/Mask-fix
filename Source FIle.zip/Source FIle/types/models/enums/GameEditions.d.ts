export declare enum GameEditions {
    STANDARD = "standard",
    LEFT_BEHIND = "left_behind",
    PREPARE_FOR_ESCAPE = "prepare_for_escape",
    EDGE_OF_DARKNESS = "edge_of_darkness",
    UNHEARD = "unheard_edition",
    TOURNAMENT = "tournament_live"
}
