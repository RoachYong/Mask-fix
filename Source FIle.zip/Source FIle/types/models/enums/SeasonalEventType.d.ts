export declare enum SeasonalEventType {
    NONE = "None",
    CHRISTMAS = "Christmas",
    HALLOWEEN = "Halloween",
    NEW_YEARS = "NewYears",
    PROMO = "Promo",
    APRIL_FOOLS = "AprilFools"
}
