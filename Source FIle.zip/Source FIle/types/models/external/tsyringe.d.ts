import type { DependencyContainer } from "tsyringe";
export type { DependencyContainer };
