Put in user/mods

Config is editable 