import { DependencyContainer } from "tsyringe";
import { ItemTpl } from "@spt/models/enums/ItemTpl";
import { IPostDBLoadMod } from "@spt/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt/servers/DatabaseServer";
import { IDatabaseTables } from "@spt/models/spt/server/IDatabaseTables";
import { ItemHelper } from "@spt/helpers/ItemHelper";
import { BaseClasses } from "@spt/models/enums/BaseClasses";

import { FileSystem } from "@spt/utils/FileSystem";
import { jsonc } from "jsonc";
import path from "path";

class maskfix implements IPostDBLoadMod

{
    public async postDBLoad(container: DependencyContainer): Promise<void>
    {
        // get database from server
        const databaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        const tables: IDatabaseTables = databaseServer.getTables();
        const itemDB = tables.templates.items;
		    const itemHelper = container.resolve<ItemHelper>("ItemHelper");

        const fs = container.resolve<FileSystem>("FileSystem");
		    const configPath = path.resolve(__dirname, "../config.jsonc");
		    const configFileContent = await fs.read(configPath);
		    const configString = configFileContent.toString();
		    const config = jsonc.parse(configString);

      for (let item in itemDB) {
			  if (itemDB[item]._type !== "Node") {
				  const itemId = itemDB[item]._id
				  if (itemHelper.isOfBaseclass(itemId, BaseClasses.FACECOVER)) {
					}
					itemDB[item]._props.BlocksHeadwear = config.FaceCover.removeBlocksHeadwear ? false : itemDB[item]._props.BlocksHeadwear;
					itemDB[item]._props.BlocksEarpiece = config.FaceCover.removeBlocksEarpiece ? false : itemDB[item]._props.BlocksEarpiece;
					itemDB[item]._props.BlocksFaceCover = config.FaceCover.removeBlocksFaceCover ? false : itemDB[item]._props.BlocksFaceCover;
					itemDB[item]._props.BlocksEyewear = config.FaceCover.removeBlocksEyewear ? false : itemDB[item]._props.BlocksEyewear;
					itemDB[item]._props.ConflictingItems = config.FaceCover.clearConflictingItems ? [] : itemDB[item]._props.ConflictingItems;
          }
        }

tables.templates.items["55d7217a4bdc2d86028b456d"]._props.Slots[13]._props.filters[0].Filter.push("5a341c4686f77469e155819e");

    }
}

export const mod = new maskfix();
